﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SistAdmin.TransferObjects
{
	public class SimplifiedExceptionTO
	{
		public string Message { get; set; }
		public string ClassName { get; set; }
	}
}