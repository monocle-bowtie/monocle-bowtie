﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SistAdmin.TransferObjects
{
    public class PreventasAPagar
    {
        public int idVenta { get; set; }
    }
}